<h2>3조 ERD</h2>
<br><br>
<h3>논리적 모델링</h3>
<img src="https://github.com/cri3958/team3_v2sbm3c/assets/48902673/2da32019-1add-4b66-b083-ec4c2d4912c4">
<br>
<h3>물리적 모델링</h3>
<img src="https://github.com/cri3958/team3_v2sbm3c/assets/48902673/298f6a9d-b332-4d8b-9e3d-2edf5150d997">
