package dev.mvc.team3_v2sbm3c;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team3V2sbm3cApplicationTests {

	@Test
	void contextLoads() {
	}

}
